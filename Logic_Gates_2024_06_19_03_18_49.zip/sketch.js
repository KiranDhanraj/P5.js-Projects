var and1;

var and2;
var xor1;
var xor2;
var x=0
var a1on=false;
var a2on=false;
var x1on=false;
var x2on=false;
var bulb;
var xGate;
var aGate;
var a=0;






function setup() {
  createCanvas(580, 600);
  bulb=loadImage("LightBulbIconPNGImage.png")
  and1=createButton('A')
  and2=createButton('B')
  and1.mousePressed(and1Press)
  and2.mousePressed(and2Press)

  and1.size(70, 70)
  and1.position(10, 100)
  and2.size(70, 70)
  and2.position(210, 100)
  
  xor1=createButton('A')
  xor2=createButton('B')
  xor1.position(300, 100)
  xor1.size(70, 70)
  xor2.position(500, 100)
  xor2.size(70, 70)
  xor1.mousePressed(x1Press)
  xor2.mousePressed(x2Press)
  
  xGate=loadImage(" Drawing.png");
  aGate=loadImage("And.png")
}

function draw() {
  background('grey');
  
    image(xGate,362, 225, 150, 125)
    image(aGate,122.5, 250, 45, 75)


  strokeWeight(5)
  if(a1on==true && a2on==true){
  stroke(x, 0, 0)
  
  if(x<250){x+=10}
  line(45, 250, 135, 250)
  line(245, 250, 155, 250)
    
  line(245, 250, 245, 170)
  line(45, 250, 45, 170)

    
  line(145, 312, 145, 380)
  tint('yellow')
  image(bulb, 95, 350, 100, 100)
  }
  else{
  x=0
  stroke('black')
    tint('white')
    
  line(45, 250, 45, 170)
  line(245, 250, 245, 170)

  line(45, 250, 135, 250)
  line(245, 250, 155, 250)
    
  line(145, 312, 145, 380)

  image(bulb, 95, 350, 100, 100)
  }
    
    
  if(x1on!= x2on ){
    
    stroke(a,0,0)
    if(a<250){a+=10}
    tint('yellow')
    line(335, 170, 335, 250)
    line(535, 170, 535, 250)
    
    line(335, 250, 425, 250)
    line(535, 250, 445, 250)
    
    line(435, 320, 435, 380)
    image(bulb, 385, 350, 100, 100)

 }
else{
  a=0
  tint('white')
  stroke('black')
    line(335, 170, 335, 250)
    line(535, 170, 535, 250)

  
    line(335, 250, 425, 250)
    line(535, 250, 445, 250)

    line(435, 320, 435, 380)
    image(bulb, 385, 350, 100, 100)
  
  
  
  
}

    strokeWeight(1)
  stroke('white')
  line(290, 0, 290, 600)
  textSize(20)
  fill('white')
  text("AND Gate", 90, 50)
  text("XOR Gate", 385, 50)
  tint('white')
  

}
function and1Press(){
  if(a1on==false){
  and1.style('background-color', 'yellow');
    a1on=true
  }
  else{
  and1.style('background-color', 'white')
    a1on=false
  }
}
function and2Press(){
  if(a2on==false){
  and2.style('background-color', 'yellow');
    a2on=true
  }
  else{
  and2.style('background-color', 'white')
    a2on=false
  }
  
}

function x1Press(){
  if(x1on==false){
    xor1.style('background-color', 'yellow');
    x1on=true
  }
  else{
  xor1.style('background-color', 'white')
    x1on=false
  }
}
function x2Press(){
  if(x2on==false){
  xor2.style('background-color', 'yellow');
    x2on=true
  }
  else{
  xor2.style('background-color', 'white')
    x2on=false
  }
}
function mousePressed(){
  print(mouseX, mouseY)
}